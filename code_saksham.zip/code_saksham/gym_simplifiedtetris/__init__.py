"""Import the envs module so that the envs register themselves in Gym."""

from .envs import *
