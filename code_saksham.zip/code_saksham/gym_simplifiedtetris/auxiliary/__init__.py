"""Initialise auxiliary."""

from gym_simplifiedtetris.auxiliary.colours import Colours
from gym_simplifiedtetris.auxiliary.polymino import Polymino

__all__ = []
