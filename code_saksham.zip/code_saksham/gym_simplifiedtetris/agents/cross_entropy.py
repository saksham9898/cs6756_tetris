
from copy import deepcopy
from gym_simplifiedtetris.agents.base import BaseAgent
from gym_simplifiedtetris.agents.dellacherie import DellacherieAgent
from gym_simplifiedtetris.envs._simplified_tetris_engine import SimplifiedTetrisEngine
from typing import Any
import numpy as np


class CrossEntropyAgent(DellacherieAgent):
    """An agent that selects actions based on Dellacherie feature set but with weights
    trained using Cross Entropy
    """
    def __init__(self) -> None:
        """Initialize the mean and variance of the distribution from which the weight
        vectors will be draw
        """
        super().__init__()
        self.MEANS = np.zeros(6, dtype="double")
        self.STD_DEV = 10*np.ones(6, dtype="double")

    def predict(self, env: SimplifiedTetrisEngine, weights,  **kwargs: Any) -> int:
        """Return the action yielding the largest heuristic score, weighted by cross entropy.

        Ties are separated using a priority rating, which is based on the translation and rotation of the current piece.

        :param env: environment that the agent resides in.
        :return: action with the largest rating (where ties are separated based on the priority).
        """
        CE_scores = self._compute_CE_scores(env, weights)
        return np.argmax(CE_scores)

    def _compute_CE_scores(self, env: SimplifiedTetrisEngine, weights: np.ndarray)-> np.ndarray:
        """Compute and return scores weighted by CE
        """
        scores = np.empty((env.num_actions,), dtype="double")
        available_actions = env._engine._all_available_actions[env._engine._piece._id]

        for action, (translation, rotation) in available_actions.items():
            old_grid = deepcopy(env._engine._grid)
            old_colour_grid = deepcopy(env._engine._colour_grid)
            old_anchor = deepcopy(env._engine._anchor)

            env._engine._rotate_piece(rotation)
            env._engine._anchor = [translation, 0]

            env._engine._hard_drop()
            env._engine._update_grid(True)
            env._engine._clear_rows()

            feature_values = np.array(
                [func(env) for func in self._get_dell_funcs()], dtype="double"
            )
            scores[action] = np.dot(feature_values, weights)

            env._engine._update_grid(False)
            env._engine._grid = deepcopy(old_grid)
            env._engine._colour_grid = deepcopy(old_colour_grid)
            env._engine._anchor = deepcopy(old_anchor)

        best_actions = np.argwhere(scores == np.amax(scores)).flatten()
        is_a_tie = len(best_actions) > 1

        # Resort to the priorities if there is a tie.
        if is_a_tie:
            return self._get_priorities(
                best_actions=best_actions,
                available_actions=available_actions,
                x_spawn_pos=env._width_ / 2 + 1,
                num_actions=env.num_actions,
            )
        return scores

    def train(
        self,
        env: SimplifiedTetrisEngine,
        num_iterations: int = 100,
        samples: int = 20,
        top: float = 4,
        render: bool = False):

        score_log = []
        for iteration in range(1, num_iterations + 1):
            # GENERATE N WEIGHT VECTORS (N x 6 matrix)
            W = np.random.normal(self.MEANS, self.STD_DEV, size=(samples, 6))
            
            #Play games with each sample and keep track of score
            scores = np.zeros(shape=(samples,))
            for idx, w in enumerate(W):
                scores[idx] = self.play_games(env= env, weight=w, num_games=1, max_steps=10000)
            print(scores)
            sorted_idx = np.argsort(scores)
            W = W[sorted_idx[-top:]]
            self.MEANS = np.mean(W, axis=0)
            self.STD_DEV = np.std(W, axis=0) + 2  #constant noise

            if(iteration % 10 == 0):
                avg_score = self.play_games(env=env, weight=self.MEANS, num_games=1, max_steps=10000, render=render)
                avg_score /= 1
                print(avg_score)
                score_log.append(avg_score)
            
        return score_log 



        

    def play_games(self, env: SimplifiedTetrisEngine, weight: np.ndarray, num_games: int, max_steps: int = 1000, render: bool = False) -> int:
        total_score = 0
        for i in range(num_games):
            obs = env.reset()
            # score = 0
            for step in range(max_steps):
                if render:
                    env.render()
                action = self.predict(env, weights=weight)
                obs, reward, done, info = env.step(action)
                total_score += reward
                if done:
                    break
        env.close()
        return total_score
