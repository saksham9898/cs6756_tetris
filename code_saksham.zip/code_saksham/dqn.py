import numpy as np
import torch.nn as nn
import random
from torch import optim
import torch
from torch.utils.data import Dataset, DataLoader
import pickle
from gym_simplifiedtetris.envs.simplified_tetris_binary_env import SimplifiedTetrisBinaryEnv as Tetris
from gym_simplifiedtetris.agents.dellacherie import DellacherieAgent
from copy import deepcopy
import faulthandler

class ExperienceBuffer:
    def __init__(self, buffer_size=2000):
        self.buffer = []
        self.buffer_size = buffer_size

    def add(self, experience):
        if len(self.buffer) + len(experience) >= self.buffer_size:
            self.buffer[0:(len(experience) + len(self.buffer)) - self.buffer_size] = []
        self.buffer.append(experience)

    def sample(self, size):
        return random.sample(self.buffer, size)

class ExperienceDataset(Dataset):
    def __init__(self, features, values):
        self.features = features
        self.values = values

    def __len__(self):
        return len(self.features)
    
    def __getitem__(self, index):
        _x = self.features[index]
        _y = self.values[index]
        return _x, _y


class Q_network(DellacherieAgent):

    def __init__(self, state_size=6, discount = 1, epsilon = 1, epsilon_min = 0.01, epsilon_decay = 0.995) -> None:
        super().__init__()
        
        self.net = self.create_net(input_dim=state_size)
        self.discount = discount
        self.epsilon = epsilon
        self.epsilon_min = epsilon_min
        self.epsilon_decay = epsilon_decay
        self.experiences = ExperienceBuffer(buffer_size=10000)
        self.loss_fn = nn.MSELoss()
        self.opt = optim.Adam(self.net.parameters())

    
    def create_net(self, input_dim: int):
        layers = [
            nn.Linear(in_features=input_dim, out_features=32),
            nn.ReLU(),
            nn.Linear(in_features=32, out_features=32),
            nn.ReLU(),
            nn.Linear(in_features=32, out_features=1),
        ]
        return nn.Sequential(*layers)
    
    def get_dell_scores(self, env: Tetris):

        feature_values = np.array(
                [func(env) for func in self._get_dell_funcs()], dtype="double"
            )
        return feature_values

    def eps_greedy_policy(self, env: Tetris, eps):
    
        if(random.uniform(0,1) < eps):
            return env.action_space.sample()
        
        action_ratings = self.get_action_ratings(env, num_actions=34)
        return np.argmax(action_ratings)
        

    def get_action_ratings(self, env: Tetris, num_actions: int=34):
        ratings = np.empty(shape=(34,), dtype="double")
        for action in range(num_actions):
            env_copy = deepcopy(env)
            _, r, done, _ = env_copy.step(action)
            #modify rewards:
            r = (r*10)**2
            if not done:
                r += 1.0
                next_features = self.get_dell_scores(env=env_copy)
                ratings[action] = r + self.net(torch.from_numpy(next_features).float())
            else:
                r = -5.0
                ratings[action] = r
        del env_copy
        return ratings
        

    def train(self, env, num_episodes=1, epochs=10):

        total_rewards = []
        reward_progress = []
        step_progress = []
        for ep in range(num_episodes):
            print("Playing episodes: ", ep)
            obs = env.reset()
            score = 0
            prev_features = self.get_dell_scores(env)
            for step in range(1000):
                action = self.eps_greedy_policy(env, self.epsilon)
                _, reward, done, info = env.step(action)
                #modify rewards:
                reward = (reward*10)**2
                if not done:
                    reward += 1.0
                else:
                    reward = -5.0
                curr_features = self.get_dell_scores(env)
                self.experiences.add([prev_features, reward, curr_features, done])
                prev_features = curr_features
                score += reward
                if done:
                    break

            total_rewards.append(score)
            print("Score: ", score, "Steps: ", step)
            self.learn(epochs=epochs)
            if(ep % 100 == 99):
                self.net.eval()
                obs = env.reset()
                score = 0
                for step in range(10000):
                    action = self.eps_greedy_policy(env, eps=0)
                    _,r , done, _ = env.step(action)
                    r = (r*10)**2
                    if not done:
                        r += 1.0
                    else:
                        r = -5.0
                    score += r
                    if done:
                        break
                reward_progress.append(score)
                print("Greedy Score: ", score, "Steps: ", step)
                step_progress.append(step)
                with open('logs/reward_log.pkl', 'wb') as outp:
                    pickle.dump(reward_progress, outp, protocol=pickle.HIGHEST_PROTOCOL)
                outp.close()
                with open('logs/step_log.pkl', 'wb') as outp:
                    pickle.dump(step_progress, outp, protocol=pickle.HIGHEST_PROTOCOL)
                outp.close()
                PATH = "logs/model_" + str(ep+1) + ".pt"
                torch.save({
                    'epoch': ep,
                    'model_state_dict': self.net.state_dict(),
                    'optimizer_state_dict': self.opt.state_dict(),
                    'epsilon': self.epsilon
                }, PATH)
                self.net.train()
            
        return total_rewards, reward_progress, step_progress

    def learn(self, batch_size=512, epochs=10):
        # print("starting learning")
        if (len(self.experiences.buffer) < batch_size):
            # print("not enough data yet")
            return

        batch = self.experiences.sample(batch_size)
        train_x = []
        train_y = []
        for prev_features, reward, next_features, done in batch:
            if done:
                q = reward
            else:
                q = reward + self.discount*self.net(torch.from_numpy(next_features).float())
                q = q.detach().numpy()[0]
            train_x.append(prev_features)
            train_y.append(q)
        train_y = torch.from_numpy(np.array(train_y)).float()
        train_x = torch.stack([torch.from_numpy(x) for x in train_x], dim=0).to(dtype=torch.float32)

        training_set = ExperienceDataset(train_x, train_y)
        training_loader = DataLoader(training_set, batch_size=64, shuffle=True)

        for epoch in range(epochs):
            running_loss = 0.0
            for i, data in enumerate(training_loader):
                features, values = data
                self.opt.zero_grad()
                pred = self.net(features)
                pred = torch.reshape(pred, shape=(-1,))
                loss = self.loss_fn(pred, values)
                loss.backward()
                self.opt.step()

                running_loss += loss.item()

            avg_loss = running_loss/(i + 1)
            # if(epoch % 50 == 49):
                # print(f'Epoch : {epoch + 1}, LOSS train {avg_loss:.3f}')
        
        self.epsilon = max(self.epsilon_min, self.epsilon*self.epsilon_decay)
        print("New epsilon = ", self.epsilon)


if (__name__=='__main__'):
    faulthandler.enable()
    env = Tetris(grid_dims=(20,10), piece_size=4)
    agent = Q_network(state_size=6)
    total_rewards, reward_log, step_log  = agent.train(env=env, num_episodes=10000, epochs=10)
    # print(reward_log)